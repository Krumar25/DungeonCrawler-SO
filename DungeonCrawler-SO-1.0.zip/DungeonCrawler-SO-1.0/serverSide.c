#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include<unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>

int main(int argc, char * argv[]){
	int sock_conn, sock_listen, ret;
	struct sockaddr_in serv_adr;
	char peticion[512];
	char respuesta[512];
	//Abrimos el socket
	if((sock_listen = socket(AF_INET, SOCK_STREAM, 0)) < 0){
		printf("Error creando el socket");
	}
	memset(&serv_adr, 0, sizeof(serv_adr)); //inicializar serv_adr a 0
	serv_adr.sin_family = AF_INET;
	
	//Asociar el socket a cualquiera de las IP de la maquina
	serv_adr.sin_addr.s_addr = htonl(INADDR_ANY);
	//escucharemos en el port 9050
	serv_adr.sin_port = htons(9080);
	if(bind(sock_listen,(struct sockaddr *) &serv_adr, sizeof(serv_adr)) < 0)
		printf("Error en el bind");
	if(listen(sock_listen,3) <0){
		printf("Error en el listen");
	}
	
	int i;
	for(i=0; i<5;i++){
		printf("Escuchando\n");
		sock_conn = accept(sock_listen,NULL,NULL);//este es el socket que usamos para comunicarnos con el cliente, que es distinto al que usamos para escuchar
		printf("He recibido conexion\n");
		
		close(sock_conn);
	}
	
	return 0;
}
